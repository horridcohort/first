module DaresHelper
	
end
