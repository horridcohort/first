module PointsHelper
end
