class Video < ActiveRecord::Base
	belongs_to :dare
end
